$(document).ready(function() {
    // Initialize DataTables
    const supervisorsTable = $('#supervisorsTable').DataTable({
        language: {
            url: '//cdn.datatables.net/plug-ins/1.10.24/i18n/Arabic.json'
        }
    });

    // View Volunteers
    $(document).on('click', '.view-volunteers', function() {
        const supervisorId = $(this).data('id');
        
        
        $.ajax({
            url: 'ajax/get_volunteers.php',
            type: 'GET',
            data: { supervisor_id: supervisorId },
            success: function(response) {
                $('#volunteersTable tbody').html(response);
                $('#volunteersModal').modal('show');
            },
            error: function() {
                alert('حدث خطأ أثناء جلب بيانات المتطوعين');
            }
        });
    });

 });

    // Delete Supervisor
    // $(document).on('click', '.delete-supervisor', function() {
        
    //     console.log('المشرف المحدد:', $(this).data());

    //     if (confirm('هل أنت متأكد من حذف هذا المشرف وجميع المتطوعين التابعين له؟')) {
    //         const supervisorId = $(this).data('id');
            
        
    //         $.ajax({
    //             url: 'ajax/delete_supervisor.php',
    //             type: 'POST',
    //             data: { id: supervisorId },
    //             success: function(response) {
    //                 if (response.success) {
    //                     location.reload();
    //                 }else {
    //                 console.error('هنا تفاصيل الخطأ:', response);
                    
    //                 let message = 'للاسف حدث خطأ أثناء حذف المشرف.';
    //                 if (response.message) {
    //                     message += '\nالرسالة: ' + response.message;
    //                 }
                
    //                 alert(message);
    //              }
    //              },
    //               error: function(xhr, status, error) {
    //                 console.error('AJAX Error:', xhr.responseText);
    //                 alert('حدث خطأ في الحذف: ' + xhr.responseText);
    //             }
    //         });
    //     }
    // });


 


