<?php
session_start();
require_once('../../process.php');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    die('Unauthorized access');
}

$id = $_GET['id'] ?? 0;

$query = "SELECT * FROM supervisors WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$supervisor = $result->fetch_assoc();

echo json_encode($supervisor);

$stmt->close();
$conn->close();
?>
