<?php
session_start();
require_once('../../process.php');
$base_url = 'https://register.bakeelmurshed.com/registerpage';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    die('Unauthorized access');
}

$supervisor_id = $_GET['supervisor_id'] ?? 0;

$query = "SELECT * FROM volunteers WHERE supervisor_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $supervisor_id);
$stmt->execute();
$result = $stmt->get_result();

while ($volunteer = $result->fetch_assoc()) {
    echo "<tr>";
    echo "<td>" . htmlspecialchars($volunteer['name']) . "</td>";
    echo "<td>" . htmlspecialchars($volunteer['national_id']) . "</td>";
    echo "<td>" . htmlspecialchars($volunteer['phone']) . "</td>";
    echo "<td>" . htmlspecialchars($volunteer['age']) . "</td>";
    echo "<td>" . ($volunteer['previous_volunteer'] === 'yes' ? 'نعم' : 'لا') . "</td>";
    echo "<td>";
    if (!empty($volunteer['previous_photo_path'])) {
        echo "<a href='" . $base_url . '/' . htmlspecialchars($volunteer['previous_photo_path']) . "' target='_blank' class='btn btn-sm btn-info mb-1'>ملفات</a>";
    } else {
        echo "لا توجد";
    }
    
    echo "<br></td>";
    // echo "<td> <a href='" . $base_url .'/'. htmlspecialchars($volunteer['previous_photo_path']) . "' target='_blank' class='btn btn-sm btn-info mb-1'>ملفات  </a><br> </td>";
    echo "<td>" . htmlspecialchars($volunteer['volunteer_text']) . "</td>";
    
    echo "<td>" . ($volunteer['platform_account'] === 'yes' ? 'نعم' : 'لا') . "</td>";
    
    // Health issues display
    $healthIssues = $volunteer['health_issues'];
    $healthDetails = $volunteer['health_details'];
    $healthText = empty($healthIssues) ? 'لا يوجد' : htmlspecialchars($healthIssues);
    if (!empty($healthDetails)) {
        $healthText .= ' - ' . htmlspecialchars($healthDetails);
    }
    echo "<td>" . $healthText . "</td>";
    
    echo "<td>" . htmlspecialchars($volunteer['tshirt_size']) . "</td>";
    echo "<td>" . htmlspecialchars($volunteer['blood']) . "</td>";
    
    // Attachments with download links
      echo "<td>
            <a href='" . $base_url . '/'.htmlspecialchars($volunteer['id_photo_path']) . "' target='_blank' class='btn btn-sm btn-info mb-1'>الهوية</a><br>
            <a href='" . $base_url . '/'.htmlspecialchars($volunteer['personal_photo_path']) . "' target='_blank' class='btn btn-sm btn-info'>الصورة الشخصية</a>
          </td>";

}

$stmt->close();
$conn->close();
?>
