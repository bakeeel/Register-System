<?php
session_start();
require_once('../process.php');
require 'vendor/autoload.php';

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

// Create new Spreadsheet object
$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();

// Set headers
$headers = ['الاسم', 'الهوية', 'الجوال', 'العمر', 'خبرة تطوع سابقة', 'منصة التطوع', 'المشاكل الصحية', 'التيشرت', 'الدم', 'المشرف'];
$col = 'A';
foreach ($headers as $header) {
    $sheet->setCellValue($col . '1', $header);
    $sheet->getColumnDimension($col)->setAutoSize(true);
    $col++;
}

// Get all volunteers data
$query = "SELECT * FROM volunteers ORDER BY id DESC";
$result = $conn->query($query);

$row = 2;
while ($volunteer = $result->fetch_assoc()) {
    $sheet->setCellValue('A' . $row, $volunteer['name']);
    $sheet->setCellValue('B' . $row, $volunteer['national_id']);
    $sheet->setCellValue('C' . $row, $volunteer['phone']);
    $sheet->setCellValue('D' . $row, $volunteer['age']);
    $sheet->setCellValue('E' . $row, $volunteer['previous_volunteer']);
    // $sheet->setCellValue('F' . $row, $volunteer['volunteer_text']);
    // $sheet->setCellValue('G' . $row, $volunteer['health_details']);
    $sheet->setCellValue('F' . $row, $volunteer['platform_account']);
    $sheet->setCellValue('G' . $row, $volunteer['health_issues']);
    $sheet->setCellValue('H' . $row, $volunteer['tshirt_size']);
    $sheet->setCellValue('I' . $row, $volunteer['blood']);
    $sheet->setCellValue('J' . $row, $volunteer['supervisor_id']);
    $row++;
}

// Set RTL direction for the worksheet
$sheet->setRightToLeft(true);

// Create Excel file
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment;filename="volunteers_data.xlsx"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
