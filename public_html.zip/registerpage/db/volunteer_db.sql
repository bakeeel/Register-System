-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 26 أبريل 2025 الساعة 17:28
-- إصدار الخادم: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `volunteer_db`
--

-- --------------------------------------------------------

--
-- بنية الجدول `associations`
--

CREATE TABLE `associations` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `associations`
--

INSERT INTO `associations` (`id`, `name`, `address`, `city`) VALUES
(1, 'جمعية البر', 'شارع الملك فهد', 'الرياض'),
(2, 'جمعية الخير', 'شارع الأمير محمد', 'جدة'),
(3, 'جمعية كهاتين22', 'مكةالنسيم', 'مكة');

-- --------------------------------------------------------

--
-- بنية الجدول `supervisors`
--

CREATE TABLE `supervisors` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `association_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `supervisors`
--

INSERT INTO `supervisors` (`id`, `name`, `phone`, `association_id`) VALUES
(6, 'جلال محمد سعيد', '0536892909', 1),
(11, 'جلال محمد سعيد القهالي', '0536892897', 2),
(12, 'بكيل احمد محمد مرشد', '0578979879', 1),
(13, 'صدام التنواري', '6879879546', 2),
(14, 'محمد قاسم', '5684444444', 3);

-- --------------------------------------------------------

--
-- بنية الجدول `volunteers`
--

CREATE TABLE `volunteers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `national_id` varchar(20) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `age` int(11) NOT NULL,
  `previous_volunteer` enum('yes','no') NOT NULL,
  `platform_account` enum('yes','no') NOT NULL,
  `health_issues` varchar(50) DEFAULT NULL,
  `health_details` text DEFAULT NULL,
  `tshirt_size` enum('S','M','XL','XXL') NOT NULL,
  `id_photo_path` varchar(255) NOT NULL,
  `personal_photo_path` varchar(255) NOT NULL,
  `supervisor_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- إرجاع أو استيراد بيانات الجدول `volunteers`
--

INSERT INTO `volunteers` (`id`, `name`, `national_id`, `phone`, `age`, `previous_volunteer`, `platform_account`, `health_issues`, `health_details`, `tshirt_size`, `id_photo_path`, `personal_photo_path`, `supervisor_id`, `created_at`) VALUES
(1, 'محمد سعيد', '2552227924', '0536892909', 18, 'no', 'no', 'hearing', '', 'S', 'uploads/680ba36630ccc.jpeg', 'uploads/680ba366317a2.png', 6, '2025-04-25 14:59:50'),
(6, 'تامر حسن', '2552227923', '0536892902', 17, 'no', 'no', 'hearing', '', 'M', 'uploads/680baa0698ce9.png', 'uploads/680baa0698e98.png', 11, '2025-04-25 15:28:06'),
(7, 'محسن سعيد', '2552227738', '0536892904', 17, 'yes', 'yes', '', '', 'XL', 'uploads/680baa0699305.png', 'uploads/680baa0699432.pdf', 11, '2025-04-25 15:28:06'),
(8, 'جابر احمد', '2552227111', '0536892900', 17, 'no', 'yes', 'physical', '', 'XXL', 'uploads/680baa069984d.pdf', 'uploads/680baa0699971.jpg', 11, '2025-04-25 15:28:06'),
(9, 'عمر عبد مقبل سعيد', '8987898888', '5464566666', 18, 'yes', 'no', '', '', 'XL', 'uploads/680ccc3c64b1f.jpg', 'uploads/680ccc3c64d93.jpg', 12, '2025-04-26 12:06:20'),
(10, 'علي محمد علي', '4897498888', '5465666666', 19, 'yes', 'yes', '', '', 'S', 'uploads/680ce30588cfb.jpg', 'uploads/680ce30588ff3.jpg', 13, '2025-04-26 13:43:33'),
(11, 'ياسر قاسك', '8954444444', '4566666666', 18, 'no', 'yes', '', '', 'XL', 'uploads/680cfb0cb81ee.jpg', 'uploads/680cfb0cb8427.jpg', 14, '2025-04-26 15:26:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `associations`
--
ALTER TABLE `associations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supervisors`
--
ALTER TABLE `supervisors`
  ADD PRIMARY KEY (`id`),
  ADD KEY `association_id` (`association_id`);

--
-- Indexes for table `volunteers`
--
ALTER TABLE `volunteers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `national_id` (`national_id`),
  ADD KEY `supervisor_id` (`supervisor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `associations`
--
ALTER TABLE `associations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `supervisors`
--
ALTER TABLE `supervisors`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `volunteers`
--
ALTER TABLE `volunteers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- قيود الجداول المُلقاة.
--

--
-- قيود الجداول `supervisors`
--
ALTER TABLE `supervisors`
  ADD CONSTRAINT `supervisors_ibfk_1` FOREIGN KEY (`association_id`) REFERENCES `associations` (`id`);

--
-- قيود الجداول `volunteers`
--
ALTER TABLE `volunteers`
  ADD CONSTRAINT `volunteers_ibfk_1` FOREIGN KEY (`supervisor_id`) REFERENCES `supervisors` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
