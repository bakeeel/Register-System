<?php
session_start();
require_once('../process.php');

if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit;
}

// Get all supervisors with their volunteers

$query = "SELECT s.*,
          (SELECT COUNT(*) FROM volunteers v WHERE v.supervisor_id = s.id) as volunteer_count
          FROM supervisors s
          ORDER BY s.id DESC";
$supervisors = $conn->query($query);

?>
<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - مبادرة عطاء وإثراء</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/datatables@1.10.18/media/css/jquery.dataTables.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary" style="background-color: #03a99f !important;">
        <div class="container">
            <a class="navbar-brand" href="#">لوحة التحكم</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link active" href="dashboard.php">الرئيسية</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="logout.php">تسجيل الخروج</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <div class="container mt-4">
        <h2 class="mb-4">قائمة المشرفين والمتطوعين</h2>
        
        <div class="table-responsive">
            <table class="table table-striped" id="supervisorsTable">
                <thead>
                    <tr>
                        <th>الرقم</th>
                        <th>اسم المشرف</th>
                        <th>رقم الجوال</th>
                        <th>الجمعية</th>
                        <th>عدد المتطوعين</th>
                        <th>الإجراءات</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($supervisor = $supervisors->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($supervisor['id']); ?></td>
                        <td><?php echo htmlspecialchars($supervisor['name']); ?></td>
                        <td><?php echo htmlspecialchars($supervisor['phone']); ?></td>
                        <td><?php echo htmlspecialchars($supervisor['association_name']); ?></td>
                        <td><?php echo htmlspecialchars($supervisor['volunteer_count']); ?></td>
                        
                        <td>
                            <button class="btn btn-info btn-sm view-volunteers" data-id="<?php echo $supervisor['id']; ?>">
                                عرض المتطوعين
                            </button>
                          
                            <!--<button class="btn btn-danger btn-sm delete-supervisor" data-id="<?php echo $supervisor['id']; ?>">-->
                            <!--    حذف-->
                            <!--</button>-->
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal for Viewing Volunteers -->
    <div class="modal fade" id="volunteersModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">قائمة المتطوعين</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table table-striped" id="volunteersTable">
                            <thead>
                                <tr>
                                    <th>الاسم</th>
                                    <th> الهوية</th>
                                    <th>الجوال</th>
                                    <th>العمر</th>
                                    <th>خبرة تطوع سابقة</th>
                                    <th>الاعمال السابقه</th>
                                    <th>عمل سابق</th>
                                    <th> منصة التطوع</th>
                                    <th>المشاكل الصحية</th>
                                    <th>التيشرت</th>
                                    <th>الدم</th>
                                    <th>المرفقات</th>
                                  
                                </tr>
                            </thead>
                            <tbody></tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>



   

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/datatables@1.10.18/media/js/jquery.dataTables.min.js"></script>
    <script src="admin.js"></script>
</body>
</html>
