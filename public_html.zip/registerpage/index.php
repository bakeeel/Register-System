<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="logo2.png">
    <title>مبادرة عطاء وإثراء - نموذج التسجيل</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Bootstrap Select CSS -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.14.0-beta3/dist/css/bootstrap-select.min.css">

    <link rel="stylesheet" href="style.css">
    
    <style>
           
                @font-face {
                font-family: 'TS Rotger';
                src: url('fonts/ArbFONTS-Changa-Regular.ttf') format('truetype') ;
                font-weight: normal;
                font-style: normal;
            }
    
            body {
                font-family: 'TS Rotger', Arial, sans-serif;
                min-height: 66vh;
                display: flex;
                justify-content: center;
                align-items: center;
            }
    </style>
        
</head>
<body>
    <div class="container">
        <div class="form-container">
            <img src="logo2.png" alt="logo" style="display: block; margin: 0 auto;">
            <h1 class="text-center mb-4">نموذج التسجيل في مبادرة "عطاء وإثراء"</h1>
            <form id="registrationForm" action="process.php" method="POST" enctype="multipart/form-data">
                <!-- اختيار الجمعية -->
                <div class="section-container">
                  <h3>بيان الجمعية</h3>
               <div class="form-group mb-3">
                <label for="association">اسم الجمعية</label>
                <select class="form-control selectpicker" id="association" name="association_name" data-dropup-auto="false" required>
                    <option value="">اختر الجمعية</option>
                    <option value="الجمعية الخيرية لرعاية الأيتام بمنطقة مكة كافل">الجمعية الخيرية لرعاية الأيتام بمنطقة مكة كافل</option>
                    <option value="الجمعية الخيرية لرعاية الأيتام بمنطقة مكة كهاتين">الجمعية الخيرية لرعاية الأيتام بمنطقة مكة كهاتين</option>
                    <option value="جمعية تراؤف">جمعية تراؤف</option>
                    <option value="جمعية اجلال">جمعية اجلال</option>
                    <option value="جمعية ايتام الجبيل">جمعية ايتام الجبيل</option>
                    <option value="الجمعية الخيرية لرعاية الأيتام بنجران">الجمعية الخيرية لرعاية الأيتام بنجران</option>
                    <option value="جمعية رفق لرعاية الأيتام">جمعية رفق لرعاية الأيتام</option>
                    <option value="جمعية رأفة لرعاية الأيتام">جمعية رأفة لرعاية الأيتام</option>
                    <option value="جمعية رعاية الأيتام غراس">جمعية رعاية الأيتام غراس</option>
                    <option value="جمعية كيان للأيتام">جمعية كيان للأيتام</option>
                    <option value="الجمعية الخيرية لرعاية الأيتام بالمنطقة الشرقية بناء">الجمعية الخيرية لرعاية الأيتام بالمنطقة الشرقية بناء</option>
                    <option value="جمعية اباء لرعاية الأيتام">جمعية اباء لرعاية الأيتام</option>
                    <option value="المؤسسة الخيرية لرعاية الأيتام إخاء">المؤسسة الخيرية لرعاية الأيتام إخاء</option>
                    <option value="جمعية أبوة لرعاية الأيتام">جمعية أبوة لرعاية الأيتام</option>
                    <option value="جمعية أيتام جدة">جمعية أيتام جدة</option>
                    <option value="الجمعية الخيرية لرعاية الأيتام بحائل رفق">الجمعية الخيرية لرعاية الأيتام بحائل رفق</option>
                    <option value="جمعية إجلال لرعاية الأيتام">جمعية إجلال لرعاية الأيتام</option>
                    <option value="اخرى">أخرى..</option>

                </select>
            </div>
              <div id="otherAssociationContainer" class="form-group mb-3 d-none"> 
              <label for="otherAssociationName">اكتب اسم الجمعية</label> <input type="text" id="otherAssociationName" class="form-control associationName" name="associationName" > </div>
         

                   
                </div>

                <!-- بيانات المشرف -->
                <div class="section-container">
                    <h3>بيانات مشرف الجمعية</h3>
                    <div class="form-group">
                        <label for="supervisorName">الاسم الرباعي</label>
                        <input type="text" class="form-control" id="supervisorName" name="supervisorName" required>
                    </div>
                    <div class="form-group">
                        <label for="supervisorPhone">رقم الجوال</label>
                        <input type="tel" class="form-control" id="supervisorPhone" maxlength="10" name="supervisorPhone" pattern="[0-9]{10}" required>
                    </div>
                </div>

                <!-- بيانات المتطوع -->
                <div id="volunteers-container">
                    <div class="volunteer-form section-container" data-volunteer-id="1">
                        <div class="d-flex justify-content-between align-items-center">
                            <h3>بيانات المتطوع</h3>
                            <button type="button" class="btn btn-danger remove-volunteer" style="display: none;">حذف المتطوع</button>
                        </div>
                        <div class="form-group">
                            <label for="volunteerName">الاسم الرباعي</label>
                            <input type="text" class="form-control" id="volunteerName" name="volunteerName[]" required>
                        </div>
                        <div class="form-group">
                            <label for="nationalId">رقم الهوية الوطنية</label>
                            <input type="tel" class="form-control" id="nationalId" maxlength="10" name="nationalId[]" pattern="[0-9]{10}" required>
                        </div>
                        <div class="form-group">
                            <label for="volunteerPhone">رقم الجوال</label>
                            <input type="tel" class="form-control" id="volunteerPhone" maxlength="10" name="volunteerPhone[]" pattern="[0-9]{10}" required>
                        </div>
                        <div class="form-group">
                           
                        <div class="form-group">
                               <label for="volunteerAge_1">العمر</label>
                              <select class="form-control" id="age_1" name="volunteerAge[]" required>
            

                                 <option value="">اختر العمر</option>
                                 <option value="18">18</option>
                                 <option value="19">19</option>
                                 <option value="20">20</option>
                                 <option value="21">21 بعد الاعتماد  </option>

                            </select>
                        </div>
                        
                            <div class="form-group">
                               <label for="volunteerBlood">فصيلة الدم</label>
                              <select class="form-control" id="volunteerBlood" name="volunteerBlood[]" required>
                                 <option value="">اختر الفصيلة</option>
                                 <option value="O+">+O</option>
                                 <option value="O-">-O</option>
                                 <option value="A+">+A</option>
                                 <option value="A-">-A</option>
                                 <option value="B+">+B</option>
                                 <option value="B-">-B</option>
                                 <option value="AB+">+AB</option>
                                 <option value="AB-">-AB</option>
                                

                            </select>
                        </div>

                        </div>
                        <div class="form-group">
                            <label>هل سبق لك التطوع؟</label>
                            <div class="form-check">
                               <input type="radio" class="form-check-input previousVolunteer" name="previousVolunteer_1" id="previousVolunteerYes_1" value="yes" data-volunteer-id="1" required>
                                <label class="form-check-label" for="previousVolunteerYes_1">نعم</label>

                            </div>
                                    <div class="form-check">
                                        <input type="radio" class="form-check-input previousVolunteer" name="previousVolunteer_1" id="previousVolunteerNo_1" value="no" data-volunteer-id="1">
                                        <label class="form-check-label" for="previousVolunteerNo_1">لا</label>
        
                                    </div>
                                </div>
                       <!-- حقل نص وصف الأعمال التطوعية -->
                                    <div class="form-group previous-volunteer-details d-none" data-volunteer-id="1">
                                    <label>اذكر الأعمال التطوعية السابقة (إن وجدت)</label>
                                    <textarea class="form-control previousVolunteerWork" name="previousVolunteerWork_1" rows="3"></textarea>
                                </div>
                                            
                    <!-- حقل رفع ملفات متعلقة بالأعمال التطوعية -->
                               <div class="form-group previous-volunteer-details d-none" data-volunteer-id="1">
                                <label>تحميل ملفات متعلقة بالأعمال التطوعية السابقة</label>
                                <input type="file" class="form-control previousVolunteerFiles" name="previousVolunteerFiles_1[]" multiple>
                            </div>


                        <div class="form-group">
                            <label>هل لديك حساب في منصة العمل التطوعي؟</label>
                            <div class="form-check">
                                <input type="radio" class="form-check-input platformAccount" id="platformAccountYes_1" name="platformAccount_1" value="yes" required>
                                <label class="form-check-label" for="platformAccountYes_1">نعم</label>
                            </div>
                            <div class="form-check">
                                <input type="radio" class="form-check-input platformAccount" id="platformAccountNo_1" name="platformAccount_1" value="no">
                                <label class="form-check-label" for="platformAccountNo_1">لا</label>
                            </div>
                            
                            <div id="falseChoice" class="falseChoice d-none "> 
                           <label for="form-check" class="text-danger mt-1" style="font-size: small;" >للمشاركة في مبادرة وعطاء واثراء، يرجى التسجيل بمنصة العمل التطوعي</lab>

                        </div>


                            <div class="form-group">
                            <label for="healthIssues">هل تعاني من مشاكل صحية؟</label>
                            <select class="form-control healthIssues" id="healthIssues_1" name="healthIssues[]" data-volunteer-id="1">

                                <option value="">لا يوجد</option>
                                <option value="hearing">سمعية</option>
                                <option value="visual">بصرية</option>
                                <option value="physical">حركية</option>
                                <option value="physical">ضغط وسكر</option>
                                <option value="anemia"> فقر الدم </optin>
                                <option value="Asthma and pneumonia">ربو الهاب الرئة</option>
                                <option value="other">أخرى</option>
                            </select>
                            <div id="healthDetailsContainer" class="d-none mt-2">
                               <textarea class="form-control healthDetails" id="healthDetails_1" name="healthDetails[]" data-volunteer-id="1" placeholder="يرجى توضيح التفاصيل"></textarea>

                            </div>
                        </div>

                        <!-- المرفقات والمعلومات الإضافية -->
                        <div class="section-container mt-3">
                            <h4>المرفقات والمعلومات الإضافية</h4>
                            <div class="form-group">
                                <label for="tshirtSize">مقاس التيشيرت</label>
                                <select class="form-control" id="tshirtSize" name="tshirtSize[]" required>
                                    <option value="S">S</option>
                                    <option value="L">L</option>
                                    <option value="M">M</option>
                                    <option value="XL">XL</option>
                                    <option value="XXL">XXL</option>
                                     <option value="XXXL">XXXL</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="idPhoto">صورة الهوية</label>
                                <input type="file" class="form-control" id="idPhoto_1" name="idPhoto_1" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required>
                                <small class="form-text text-muted">الحد الأقصى للحجم: 100MB</small>
                            </div>
                            <div class="form-group">
                                <label for="personalPhoto">الصورة الشخصية</label>
                                <input type="file" class="form-control" id="personalPhoto" name="personalPhoto_1" accept=".pdf,.doc,.docx,.jpg,.jpeg,.png" required>
                                   <small class="form-text text-muted"> تنويه: يجب أن تكون خلفية الصورة بيضاء. </small>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="text-center mb-4">
                    <button type="button" class="btn btn-secondary" id="addVolunteer">إضافة متطوع جديد</button>
                </div>

                <div class="text-center mt-4">
                    <button type="submit" class="btn btn-primary">تسجيل</button>
                </div>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <!--<script src="script.js"></script>-->
    
    <script>
        $(document).ready(function() {
            $(document).on('change', '.previousVolunteer', function() {
                var volunteerForm = $(this).closest('.volunteer-form'); // حدد فورم المتطوع الحالي
                var selectedValue = $(this).val(); // القيمة المختارة (نعم أو لا)
        
                if (selectedValue === 'yes') {
                    volunteerForm.find('.previous-volunteer-details').removeClass('d-none');
                } else {
                    volunteerForm.find('.previous-volunteer-details').addClass('d-none');
                    // مسح القيم إذا أخفى الحقول
                    volunteerForm.find('textarea[name="previousVolunteerWork[]"]').val('');
                    volunteerForm.find('input[type="file"][name^="previousVolunteerFiles_"]').val('');
                }
            });
        });
        
        $(document).ready(function() {
            $('.selectpicker').selectpicker();
        });
        
        
        // .........
        
         $(document).ready(function () {
        let volunteerCounter = 1;

        function updateVolunteerAttributes($volunteer, id) {
            $volunteer.attr('data-volunteer-id', id);

            // تحديث أسماء وIDs للحقول
            $volunteer.find('input, select, textarea, label').each(function () {
                if ($(this).attr('name')) {
                    const name = $(this).attr('name');
                    const newName = name.replace(/\d+/, id);
                    $(this).attr('name', newName);
                }

                if ($(this).attr('id')) {
                    const idAttr = $(this).attr('id');
                    const newId = idAttr.replace(/\d+/, id);
                    $(this).attr('id', newId);
                }

                if ($(this).attr('for')) {
                    const forAttr = $(this).attr('for');
                    const newFor = forAttr.replace(/\d+/, id);
                    $(this).attr('for', newFor);
                }
            });

            // إفراغ القيم
            $volunteer.find('input[type="text"], input[type="tel"], textarea').val('');
            $volunteer.find('input[type="file"]').val('');
            $volunteer.find('input[type="radio"], input[type="checkbox"]').prop('checked', false);
            $volunteer.find('select').val('');
            // $volunteerForm.find(`textarea[name="previousVolunteerWork_${volunteerId}"]`).val('');
            $volunteer.find('.previous-volunteer-details').addClass('d-none');
        }

        $('#addVolunteer').click(function () {
            const currentVolunteers = $('.volunteer-form').length;

            if (currentVolunteers >= 5) {
                alert('لا يمكنك إضافة أكثر من 5 متطوعين.');
                return;
            }

            volunteerCounter++;

            const $newVolunteer = $('.volunteer-form').first().clone();
            updateVolunteerAttributes($newVolunteer, volunteerCounter);
            $newVolunteer.find('.remove-volunteer').show();

            $('#volunteers-container').append($newVolunteer);
        });

        // حذف متطوع
        $(document).on('click', '.remove-volunteer', function () {
            $(this).closest('.volunteer-form').remove();
        });

        // إظهار وإخفاء تفاصيل الأعمال التطوعية
        $(document).on('change', '.previousVolunteer', function () {
            const volunteerForm = $(this).closest('.volunteer-form');
            const selectedValue = $(this).val();
            const volunteerId = volunteerForm.attr('data-volunteer-id');

            if (selectedValue === 'yes') {
                volunteerForm.find(`.previous-volunteer-details[data-volunteer-id="${volunteerId}"]`).removeClass('d-none');
                
            } else {
                volunteerForm.find(`.previous-volunteer-details[data-volunteer-id="${volunteerId}"]`).addClass('d-none');
                volunteerForm.find(`textarea[name="previousVolunteerWork_${volunteerId}"]`).val('');
                volunteerForm.find(`input[name="previousVolunteerFiles_${volunteerId}[]"]`).val('');
            }
        });

        // تفعيل bootstrap-select
        $('.selectpicker').selectpicker();
    });
    
    
    
    
    // display input associationName
    
    
    document.addEventListener('DOMContentLoaded', function() {
    const associationSelect = document.getElementById('association');
    const otherAssociationContainer = document.getElementById('otherAssociationContainer');
    const otherAssociationNameInput = document.getElementById('otherAssociationName');

    if (associationSelect && otherAssociationContainer && otherAssociationNameInput) {
        function toggleOtherAssociationField() {
            if (associationSelect.value === "اخرى" ) { // هذا هو خيار "أخرى.."
                otherAssociationContainer.classList.remove('d-none');
                otherAssociationContainer.classList.add('display'); // تغيير الكلاس إلى display
                otherAssociationNameInput.required = true; // جعل الحقل مطلوبًا
            } else {
                otherAssociationContainer.classList.remove('display'); // إزالة كلاس display
                otherAssociationContainer.classList.add('d-none');   // إضافة كلاس d-none لإخفائه
                otherAssociationNameInput.required = false; // جعل الحقل غير مطلوب
                otherAssociationNameInput.value = ''; // مسح قيمة الحقل عند اختيار جمعية أخرى
            }
        }

        associationSelect.addEventListener('change', toggleOtherAssociationField);

        // استدعاء الدالة عند تحميل الصفحة للتأكد من الحالة الصحيحة إذا كان النموذج مُعبأ مسبقًا
        toggleOtherAssociationField();
    } else {
        // تسجيل خطأ في الكونسول إذا لم يتم العثور على العناصر
        if (!associationSelect) console.error('لم يتم العثور على العنصر بالمعرف "association".');
        if (!otherAssociationContainer) console.error('لم يتم العثور على العنصر بالمعرف "otherAssociationContainer".');
        if (!otherAssociationNameInput) console.error('لم يتم العثور على العنصر بالمعرف "otherAssociationName".');
    }
});



// عرض تنبيه عند اختيار "لا" لوجود حساب في منصة العمل التطوعي

    $(document).on('change', '.platformAccount', function () {
        const $volunteerForm = $(this).closest('.volunteer-form');
        const selectedValue = $(this).val();
    
    
        if (selectedValue === 'no') {
            $volunteerForm.find('.falseChoice').removeClass('d-none');
        } else {
            $volunteerForm.find('.falseChoice').addClass('d-none');
        }
    });
    
    // validation textarea
 

</script>

<!-- Bootstrap Select JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.14.0-beta3/dist/js/bootstrap-select.min.js"></script>

</body>
</html>
