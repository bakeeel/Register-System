$(document).ready(function () {
    let volunteerCount = 1;

    function createVolunteerForm() {
        // التحقق من العدد الحالي للنماذج
        const currentForms = $('.volunteer-form').length;
        if (currentForms >= 5) {
            alert('لا يمكنك إضافة أكثر من 5 متطوعين.');
            return;
        }

        volunteerCount++;

        const $firstForm = $('.volunteer-form').first();
        const $newVolunteer = $firstForm.clone();
        $newVolunteer.attr('data-volunteer-id', volunteerCount);

        // تحديث الحقول
        $newVolunteer.find('input, select, textarea').each(function () {
            const baseName = $(this).attr('name')?.split('[')[0] || '';
            const isArray = $(this).attr('name')?.includes('[]');
            const isRadio = $(this).attr('type') === 'radio';

            if (isArray) {
                $(this).val('');
            } else {
                $(this).attr('name', baseName + '_' + volunteerCount);
                if (!isRadio) $(this).val('');
                $(this).prop('checked', false);
            }

            const oldId = $(this).attr('id');
            if (oldId) {
                const newId = oldId.replace(/\d+$/, '') + volunteerCount;
                $(this).attr('id', newId);
            }
        });

        // تحديث for في <label>
        $newVolunteer.find('label').each(function () {
            const oldFor = $(this).attr('for');
            if (oldFor) {
                const newFor = oldFor.replace(/\d+$/, '') + volunteerCount;
                $(this).attr('for', newFor);
            }
        });

        // إظهار زر الحذف
        $newVolunteer.find('.remove-volunteer').show();

        // إخفاء تفاصيل المتطوع السابق
        $newVolunteer.find('.previous-volunteer-details').addClass('d-none');

        // إضافة النموذج الجديد
        $('#volunteers-container').append($newVolunteer);
    }

    // زر الإضافة
    $('#addVolunteer').click(function () {
        const currentForms = $('.volunteer-form').length;
        if (currentForms >= 5) {
            alert('لا يمكنك إضافة أكثر من 5 متطوعين');
            return;
        }
        createVolunteerForm();
    });

    // حذف النموذج
    $(document).on('click', '.remove-volunteer', function () {
        $(this).closest('.volunteer-form').remove();
    });

    // عرض/إخفاء تفاصيل المتطوع السابق
    $(document).on('change', '.previousVolunteer', function () {
        const form = $(this).closest('.volunteer-form');
        const id = form.data('volunteer-id');
        const value = $(this).val();

        if (value === 'yes') {
            form.find(`.previous-volunteer-details[data-volunteer-id="${id}"]`).removeClass('d-none');
        } else {
            form.find(`.previous-volunteer-details[data-volunteer-id="${id}"]`).addClass('d-none');
            form.find(`textarea[name="previousVolunteerWork_${id}"]`).val('');
            form.find(`input[name="previousVolunteerFiles_${id}[]"]`).val('');
        }
    });

    // تفعيل bootstrap-select
    $('.selectpicker').selectpicker();
});



