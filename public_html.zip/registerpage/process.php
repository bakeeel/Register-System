<?php
// Database configuration

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$db_host = '127.0.0.1';
$db_user = 'u260325039_bakeelReg';
$db_pass = 'bakeel712162178H@';
$db_name = 'u260325039_volunteer_db';

// إنشاء الاتصال مع قاعدة البيانات
$conn = new mysqli($db_host, $db_user, $db_pass);

// التحقق من الاتصال
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// إنشاء قاعدة البيانات إذا لم تكن موجودة
$sql = "CREATE DATABASE IF NOT EXISTS `$db_name`";
if ($conn->query($sql) === FALSE) {
    die("Error creating database: " . $conn->error);
}

// **يجب إعادة الاتصال بعد إنشاء قاعدة البيانات للتأكد من استخدام القاعدة الصحيحة**
$conn->close();
$conn = new mysqli($db_host, $db_user, $db_pass, $db_name);

// التحقق من الاتصال الجديد
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}


$conn->select_db($db_name);



$sql = "CREATE TABLE IF NOT EXISTS supervisors (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    association_name VARCHAR(255) NOT NULL
    
)";
$conn->query($sql);

$sql = "CREATE TABLE IF NOT EXISTS volunteers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    national_id VARCHAR(20) NOT NULL UNIQUE,
    phone VARCHAR(20) NOT NULL,
    age INT NOT NULL,
    previous_volunteer ENUM('yes', 'no') NOT NULL,
    previous_photo_path VARCHAR(255) NOT NULL,
    volunteer_text TEXT,
    platform_account ENUM('yes', 'no') NOT NULL,
    health_issues VARCHAR(50),
    health_details TEXT,
    tshirt_size ENUM('S', 'M', 'XL','L', 'XXL','XXXL') NOT NULL,
    volunteer_Blood ENUM('O-','O+','A+','A-','B+','B-', 'AB+', 'AB-') NOT NULL,
    id_photo_path VARCHAR(255) NOT NULL,
    personal_photo_path VARCHAR(255) NOT NULL,
    supervisor_id INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (supervisor_id) REFERENCES supervisors(id)

)";

$conn->query($sql);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $association_name=$_POST['association_name'];
if($association_name=="اخرى"){
    $association_name=$_POST['associationName'];
}

    // Set content type to JSON
    header('Content-Type: application/json');
    
    try {
        // Start transaction
        $conn->begin_transaction();

       
        
        // Insert supervisor data
        $stmt = $conn->prepare("INSERT INTO supervisors (name, phone, association_name) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $_POST['supervisorName'], $_POST['supervisorPhone'],$association_name);
        $stmt->execute();
        $supervisor_id = $stmt->insert_id;

        // Handle multiple volunteers
            $volunteer_names = $_POST['volunteerName'];
            $national_ids = $_POST['nationalId'];
            $volunteer_phones = $_POST['volunteerPhone'];
            $ages = $_POST['volunteerAge']; // <-- تم التعديل
            $tshirt_sizes = $_POST['tshirtSize'];
            $volunteer_bloods=$_POST['volunteerBlood'];
            $health_issues = $_POST['healthIssues'];
            $health_details = $_POST['healthDetails'];
            $volunteer_text=$_POST['previousVolunteerWork_1'];
            
            $previous_volunteers = [];
            $platform_accounts = [];
            
            for ($i = 0; $i < count($volunteer_names); $i++) {
                $index = $i + 1;
                $previous_volunteers[] = $_POST['previousVolunteer_' . $index] ?? 'no';
                $platform_accounts[] = $_POST['platformAccount_' . $index] ?? 'no';
            }
            
            // Create uploads directory if it doesn't exist
            $upload_dir = "uploads/";
            if (!file_exists($upload_dir)) {
                mkdir($upload_dir, 0777, true);
            }

        // Create uploads directory if it doesn't exist
        $upload_dir = "uploads/";
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }

        // Prepare volunteer insert statement
       $stmt = $conn->prepare("INSERT INTO volunteers (
            name, national_id, phone, age, previous_volunteer, previous_photo_path,volunteer_text,
            platform_account, health_issues, health_details, 
            tshirt_size,blood,id_photo_path, personal_photo_path, supervisor_id
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?)");


        // Process each volunteer
        for ($i = 0; $i < count($volunteer_names); $i++) {
            // Handle file uploads for this volunteer
            $file_index = $i + 1;
            $id_photo_key = 'idPhoto_' . $file_index;
            $personal_photo_key = 'personalPhoto_' . $file_index;
            $previous_photo_path_key = 'previousVolunteerFiles_' . $file_index;

            // Debug information
            error_log("Processing volunteer $file_index");
            error_log("Available files: " . print_r($_FILES, true));
            error_log("Looking for ID photo: $id_photo_key");
            error_log("Looking for personal photo: $personal_photo_key");

            // Check if files exist
            if (!isset($_FILES[$id_photo_key]) || !isset($_FILES[$personal_photo_key])) {
                throw new Exception("Missing required files for volunteer $file_index");
            }

            $id_photo_path = handleFileUpload($id_photo_key, $upload_dir);
            $personal_photo_path = handleFileUpload($personal_photo_key, $upload_dir);

               $stmt->bind_param("sssissssssssssi",
                $volunteer_names[$i],
                $national_ids[$i],
                $volunteer_phones[$i],
                $ages[$i],
                $previous_volunteers[$i],
                $previous_files_paths,
                $volunteer_text,
                $platform_accounts[$i],
                $health_issues[$i],
                $health_details[$i],
                $tshirt_sizes[$i],
                $volunteer_bloods[$i],
                $id_photo_path,
                $personal_photo_path,
                $supervisor_id
            );
            // echo($volunteer_Blood[$i]);

            
                $previous_files_paths = '';
                $prev_files_key = 'previousVolunteerFiles_' . $file_index;
                
                if (isset($_FILES[$prev_files_key]) && is_array($_FILES[$prev_files_key]['name'])) {
                    $uploaded_paths = [];
                    for ($j = 0; $j < count($_FILES[$prev_files_key]['name']); $j++) {
                        // Skip empty file inputs
                        if ($_FILES[$prev_files_key]['error'][$j] === UPLOAD_ERR_NO_FILE) {
                            continue;
                        }
                
                        // Create a temporary $_FILES array structure for this single file
                        $single_file = [
                            'name'     => $_FILES[$prev_files_key]['name'][$j],
                            'type'     => $_FILES[$prev_files_key]['type'][$j],
                            'tmp_name' => $_FILES[$prev_files_key]['tmp_name'][$j],
                            'error'    => $_FILES[$prev_files_key]['error'][$j],
                            'size'     => $_FILES[$prev_files_key]['size'][$j],
                        ];
                
                        $_FILES[$prev_files_key . '_' . $j] = $single_file;
                
                        // Reuse handleFileUpload function
                        $path = handleFileUpload($prev_files_key . '_' . $j, $upload_dir);
                        $uploaded_paths[] = $path;
                    }
                
                    $previous_files_paths = implode(',', $uploaded_paths);
                }


            $stmt->execute();
        }

        // Commit transaction
        $conn->commit();

    //   echo json_encode(['success' => true, 'message' => 'تم التسجيل بنجاح، شكراً ^_^'], JSON_UNESCAPED_UNICODE);
    //     exit(header("refresh: 3; url=https://register.bakeelmurshed.com/"));

           header('Content-Type: text/html; charset=utf-8');

            echo '
            <!DOCTYPE html>
            <html lang="ar" dir="rtl">
            <head>
                <meta charset="UTF-8">
                <title>تم التسجيل بنجاح</title>
                <style>
                    body { font-family: Tahoma, sans-serif; text-align: center; padding: 40px; background-color: #f9f9f9; }
                    .box { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 0 10px rgba(0,0,0,0.1); display: inline-block; }
                    .box img { max-width: 120px; margin-bottom: 20px; }
                    .box h2 { color: #03a99f; }
                    .box a { display: inline-block; margin-top: 20px; padding: 10px 20px; background-color: #03a99f; color: white; text-decoration: none; border-radius: 6px; }
                </style>
            </head>
            <body>
                <div class="box">
                    <img src="logo2.png" alt="شعار المبادرة">
                    <h2>تم التسجيل بنجاح</h2>
                    <p>شكرًا لانضمامك لمبادرة <strong>عطاء وإثراء</strong> 🌟</p>
                    <a href="https://register.bakeelmurshed.com/">العودة إلى الصفحة الرئيسية</a>
                </div>
            </body>
            </html>
            ';
        exit;

    } catch (Exception $e) {
        // Log the error
        error_log('Error in form submission: ' . $e->getMessage());
        error_log('POST data: ' . print_r($_POST, true));
        error_log('FILES data: ' . print_r($_FILES, true));
        
        // Rollback transaction on error
        $conn->rollback();
        
        $errorMessage = 'حدث خطأ أثناء تسجيل البيانات: ';
            // $errorMessage = '';
    
        if (strpos($e->getMessage(), 'foreign key constraint fails') !== false) {
            if (strpos($e->getMessage(), 'supervisors_ibfk_1') !== false) {
                $errorMessage = 'الجمعية المحددة غير موجودة.';
            } else {
                $errorMessage = 'خطأ في العلاقة بين البيانات.';
            }
        } else if (strpos($e->getMessage(), 'Duplicate entry') !== false) {
            $errorMessage = 'رقم الهوية الوطنية مسجل مسبقاً.';
        } else if (strpos($e->getMessage(), 'File not uploaded') !== false) {
            $errorMessage = 'فشل في رفع الملفات، يرجى المحاولة مرة أخرى.';
        } else if (strpos($e->getMessage(), 'Invalid file type') !== false) {
            $errorMessage = 'نوع الملف غير مدعوم.';
        } else if (strpos($e->getMessage(), 'File size exceeds limit') !== false) {
            $errorMessage = 'حجم الملف يتجاوز الحد المسموح به.';
        } else {
            $errorMessage = 'حدث خطأ غير متوقع: ' . $e->getMessage();
        }
    
        header('Content-Type: text/html; charset=utf-8');
    
         echo '
            <!DOCTYPE html>
            <html lang="ar" dir="rtl">
            <head>
                <meta charset="UTF-8">
                <title>خطأ في التسجيل</title>
                <style>
                    body { font-family: Tahoma, sans-serif; text-align: center; background-color: #fff5f5; padding: 40px; }
                    .box {
                        background: #ffffff;
                        border: 1px solid #f5c6cb;
                        color: #333;
                        padding: 30px;
                        max-width: 600px;
                        margin: auto;
                        border-radius: 10px;
                        box-shadow: 0 0 10px rgba(0,0,0,0.05);
                    }
                    .box img {
                        max-width: 100px;
                        margin-bottom: 20px;
                    }
                    .box h2 {
                        color: #e74c3c;
                        margin-bottom: 15px;
                    }
                    .box p {
                        font-size: 16px;
                        line-height: 1.7;
                    }
                    .box a {
                        display: inline-block;
                        margin-top: 20px;
                        padding: 10px 25px;
                        background-color: #e74c3c;
                        color: white;
                        text-decoration: none;
                        border-radius: 6px;
                        font-size: 15px;
                    }
                </style>
            </head>
            <body>
                <div class="box">
                    <img src="logo2.png" alt="شعار المبادرة">
                    <h2>حدث خطأ أثناء التسجيل</h2>
                    <p>' . htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8') . '</p>
                    <a href="https://register.bakeelmurshed.com/registerpage/index.php">العودة إلى الصفحة السابقة</a>
                </div>
            </body>
            </html>
            ';
    }
    $conn->close();
    exit;
}

// Function to handle file uploads
function handleFileUpload($file_key, $upload_dir) {
    if (!isset($_FILES[$file_key])) {
        error_log("File not found: $file_key");
        error_log("Available files: " . print_r($_FILES, true));
        throw new Exception("File not uploaded: " . $file_key);
    }

    if ($_FILES[$file_key]['error'] !== UPLOAD_ERR_OK) {
        $error_message = match($_FILES[$file_key]['error']) {
            UPLOAD_ERR_INI_SIZE => "الملف يتجاوز الحد الأقصى المسموح به في إعدادات PHP",
            UPLOAD_ERR_FORM_SIZE => "الملف يتجاوز الحد الأقصى المسموح به في النموذج",
            UPLOAD_ERR_PARTIAL => "تم تحميل جزء من الملف فقط",
            UPLOAD_ERR_NO_FILE => "لم يتم تحميل الملف",
            UPLOAD_ERR_NO_TMP_DIR => "المجلد المؤقت مفقود",
            UPLOAD_ERR_CANT_WRITE => "فشل في حفظ الملف",
            UPLOAD_ERR_EXTENSION => "تم إيقاف تحميل الملف بواسطة امتداد PHP",
            default => "خطأ غير معروف في تحميل الملف"
        };
        throw new Exception($error_message);
    }

    $file = $_FILES[$file_key];
    $file_extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    
    // Validate file type
    $allowed_types = ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png'];
    if (!in_array($file_extension, $allowed_types)) {
        throw new Exception("Invalid file type");
    }

    // Validate file size (100MB max)
    if ($file['size'] > 100 * 1024 * 1024) {
        throw new Exception("File size exceeds limit");
    }

    // Generate unique filename
    $new_filename = uniqid() . '.' . $file_extension;
    $upload_path = $upload_dir . $new_filename;

    // Move uploaded file
    if (!move_uploaded_file($file['tmp_name'], $upload_path)) {
        throw new Exception("Error uploading file");
    }

    return $upload_path;
}
?>
